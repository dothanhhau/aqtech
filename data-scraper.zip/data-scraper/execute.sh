#!/bin/bash

if [ -f "$2" ]; then
    echo "Executing file facebook-scraper.py..."
    python3 "$2" "$3"
    wait
    echo "Execution process completed. Exporting data to page-data.json..."
else
    echo "File facebook-scraper.py not found in the current directory."
fi