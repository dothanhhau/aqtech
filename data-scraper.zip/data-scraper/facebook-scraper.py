import json
import sys

def main():
    data = {
            "social_id": "100044355009977", 
            "avatar": "https://scontent.fdad3-5.fna.fbcdn.net/v/t39.30808-6/341698738_3484678428414649_3149233058450962120_n.jpg?_nc_cat=1&ccb=1-7&_nc_sid=5f2048&_nc_ohc=zlrymhF4EKUAX-gZojJ&_nc_ht=scontent.fdad3-5.fna&oh=00_AfDhiGKt29FX1x7hobeO6acXGHHcmcNdSbMRMFWGSyCSvQ&oe=661197D7", 
            "name": "Salim", 
            "describe": "Sà Lim", 
            "follower_count": 965444,
            "top_post": [
                {
                "post_id": "110044355055773",
                "content": "Con ở nhà với mình thì tóc buộc nhanh thôi cũng đẹp, mà sao ở với ba thì🙂",
                "image": "https://scontent.fdad3-5.fna.fbcdn.net/v/t39.30808-6/434580078_950411443114014_2276785411757320096_n.jpg?stp=cp6_dst-jpg&_nc_cat=1&ccb=1-7&_nc_sid=5f2048&_nc_ohc=rV8YyrN1LOsAX_EkdHC&_nc_ht=scontent.fdad3-5.fna&oh=00_AfDOqR79gwaPYsmPoQ0T-HxjKLa6tQsPXx3edZdorZthsg&oe=66118DC8",
                "like_count": 50671,
                "comment_count": 547,
                "share_count": 325,
                "view_count": 90671,
                "click_count": 87000,
                },
            ],
        }
    output_path = sys.argv[1]
    with open(output_path, 'w') as json_file:
        json.dump(data, json_file, indent=4)

if __name__ == "__main__":
    main()
